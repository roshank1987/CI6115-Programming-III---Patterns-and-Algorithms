package service;

import model.Treatment;
import util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TreatmentService {

    // Method to add a new treatment
    public void addTreatment(String name, double price) {
        Treatment treatment = new Treatment(name, price);
        treatment.saveToDatabase();
    }

    // Method to retrieve a treatment by ID
    public Treatment getTreatmentByID(int treatmentID) {
        return Treatment.getTreatmentByID(treatmentID);
    }

    // Method to update treatment details
    public boolean updateTreatment(int treatmentID, String name, double price) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "UPDATE Treatment SET treatmentName = ?, price = ? WHERE treatmentID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, name);
            stmt.setDouble(2, price);
            stmt.setInt(3, treatmentID);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to delete a treatment by ID
    public boolean deleteTreatment(int treatmentID) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "DELETE FROM Treatment WHERE treatmentID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, treatmentID);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to get all treatments
    public List<Treatment> getAllTreatments() {
        List<Treatment> treatments = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM Treatment";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Treatment treatment = new Treatment(
                        rs.getInt("treatmentID"),
                        rs.getString("treatmentName"),
                        rs.getDouble("price")
                );
                treatments.add(treatment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return treatments;
    }
}
