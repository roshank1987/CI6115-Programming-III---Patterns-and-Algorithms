package service;

import model.Doctor;
import util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DoctorService {

    // Method to add a new doctor
    public void addDoctor(String name, String specialized, String telephone, Map<String, List<Doctor.TimeSlot>> availability) {
        // Create a new Doctor object
        Doctor doctor = new Doctor(0, name, specialized, telephone); // doctorID is set to 0 and will be auto-generated

        // Set the provided availability
        if (availability != null) {
            for (Map.Entry<String, List<Doctor.TimeSlot>> entry : availability.entrySet()) {
                String day = entry.getKey();
                List<Doctor.TimeSlot> timeSlots = entry.getValue();
                for (Doctor.TimeSlot timeSlot : timeSlots) {
                    doctor.addAvailability(day, timeSlot.getFromTime(), timeSlot.getToTime(), timeSlot.getAvailable());
                }
            }
        }
        doctor.saveToDatabase();
    }

    // Method to retrieve a doctor by ID
    public Doctor getDoctorByID(int doctorID) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM doctors WHERE doctorID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, doctorID);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Doctor(
                        rs.getInt("doctorID"),
                        rs.getString("name"),
                        rs.getString("specialized"),
                        rs.getString("telephone")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method to update a doctor's information
    public boolean updateDoctor(int doctorID, String name, String specialized, String telephone) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "UPDATE doctors SET name = ?, specialized = ?, telephone = ? WHERE doctorID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, name);
            stmt.setString(2, specialized);
            stmt.setString(3, telephone);
            stmt.setInt(4, doctorID);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to delete a doctor by ID
    public boolean deleteDoctor(int doctorID) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "DELETE FROM doctors WHERE doctorID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, doctorID);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to retrieve all doctors
    public List<Doctor> getAllDoctors() {
        List<Doctor> doctors = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM doctors";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Doctor doctor = new Doctor(
                        rs.getInt("doctorID"),
                        rs.getString("name"),
                        rs.getString("specialized"),
                        rs.getString("telephone")
                );
                doctors.add(doctor);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return doctors;
    }
}
