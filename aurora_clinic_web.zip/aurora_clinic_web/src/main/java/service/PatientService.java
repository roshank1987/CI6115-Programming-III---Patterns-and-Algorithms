package service;

import model.Patient;
import util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PatientService {

    // Method to add a new patient
    public void addPatient(String NIC, String name, String email, String telephone) {
        Patient patient = new Patient(NIC, name, email, telephone);
        patient.saveToDatabase();
    }

    // Method to retrieve a patient by ID
    public Patient getPatientByID(int patientID) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM patients WHERE patientID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, patientID);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Patient(
                        rs.getInt("patientID"),
                        rs.getString("NIC"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("telephone")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method to retrieve a patient by NIC
    public Patient getPatientByNIC(String NIC) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM patients WHERE NIC = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, NIC);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Patient(
                        rs.getInt("patientID"),
                        rs.getString("NIC"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("telephone")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method to update a patient's information
    public boolean updatePatient(int patientID, String NIC, String name, String email, String telephone) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "UPDATE patients SET NIC = ?, name = ?, email = ?, telephone = ? WHERE patientID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, NIC);
            stmt.setString(2, name);
            stmt.setString(3, email);
            stmt.setString(4, telephone);
            stmt.setInt(5, patientID);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to delete a patient by ID
    public boolean deletePatient(int patientID) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "DELETE FROM patients WHERE patientID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, patientID);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to retrieve all patients
    public List<Patient> getAllPatients() {
        List<Patient> patients = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM patients";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Patient patient = new Patient(
                        rs.getInt("patientID"),
                        rs.getString("NIC"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("telephone")
                );
                patients.add(patient);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return patients;
    }

    // Method to check if a patient with the given NIC already exists
    public boolean doesPatientExist(String nic) {
        boolean exists = false;
        String query = "SELECT COUNT(*) FROM patients WHERE nic = ?";

        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, nic);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                int count = rs.getInt(1);
                exists = count > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return exists;
    }
}
