package service;

import model.Patient;
import model.Doctor;
import model.Treatment;
import model.Appointment;
import util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PatientAppointmentService {

    private PatientService patientService;
    private DoctorService doctorService;
    private TreatmentService treatmentService;

    public PatientAppointmentService() {
        this.patientService = new PatientService();
        this.doctorService = new DoctorService();
        this.treatmentService = new TreatmentService();
    }

    // Method to search for a patient by NIC
    public Patient searchPatientByNIC(String NIC) {
        return patientService.getPatientByNIC(NIC);
    }

    // Method to register a new patient
    public Patient registerNewPatient(String NIC, String name, String email, String telephone) {
        Patient patient = new Patient(NIC, name, email, telephone);
        patient.saveToDatabase();
        return patient;
    }

    // Method to book an appointment for a patient
    public Appointment bookAppointment(Patient patient, int doctorID, int treatmentID, String appointmentDate) {
        Doctor doctor = doctorService.getDoctorByID(doctorID);
        Treatment treatment = treatmentService.getTreatmentByID(treatmentID);
        Appointment appointment = new Appointment(0, patient, doctor, treatment, appointmentDate,0, "Scheduled");
        appointment.saveToDatabase();
        return appointment;
    }

    // Method to get all doctors
    public List<Doctor> getAllDoctors() {
        return doctorService.getAllDoctors();
    }

    // Method to get all doctors
    public List<Treatment> getAllTreatments() {
        return treatmentService.getAllTreatments();
    }

    // Method to get appointments for a patient
    public List<Appointment> getAppointmentsByPatientID(int patientID) {
        List<Appointment> appointments = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM appointments WHERE patientID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, patientID);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Patient patient = patientService.getPatientByID(rs.getInt("patientID"));
                Doctor doctor = doctorService.getDoctorByID(rs.getInt("doctorID"));
                Treatment treatment = treatmentService.getTreatmentByID(rs.getInt("treatmentID"));
                Appointment appointment = new Appointment(
                      rs.getInt("appointmentID"),
                        patient,
                        doctor,
                        treatment,
                        rs.getString("appointmentDate"),
                        rs.getInt("appointmentNo"),
                        rs.getString("status")
                );
                appointments.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return appointments;
    }
}
