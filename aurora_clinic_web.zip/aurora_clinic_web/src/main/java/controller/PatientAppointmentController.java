package controller;

import com.google.gson.Gson;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import service.PatientAppointmentService;
import model.Patient;
import model.Doctor;
import model.Treatment;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import model.Appointment;

@WebServlet("/PatientAppointmentController")
public class PatientAppointmentController extends HttpServlet {

    private PatientAppointmentService patientAppointmentService;

    @Override
    public void init() throws ServletException {
        // Initialize the service
        patientAppointmentService = new PatientAppointmentService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("registerAndBook".equals(action)) {
            registerPatientAndBookAppointment(request, response);
        } else {
            response.sendRedirect("error.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        switch (action) {
            case "searchPatient":
                searchPatient(request, response);
                break;
            case "getTimeSlots":
                int doctorID = Integer.parseInt(request.getParameter("doctorID"));
                Doctor doctor = Doctor.getDoctorByID(doctorID);

                if (doctor != null) {
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    PrintWriter out = response.getWriter();

                    String dateString = request.getParameter("appointmentDate");
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate localDate = LocalDate.parse(dateString, formatter);
                    String dayName = localDate.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH);

                    Map<String, Object> responseData = new HashMap<>();

                    List<Doctor.TimeSlot> availableTimeSlots = doctor.getAvailableTimeSlots(dayName);
                    responseData.put("timeSlots", availableTimeSlots);

                    int totalAppointments = Appointment.getAppointmentCountByDoctorAndDate(doctorID, dateString); // Get appointment count
                    responseData.put("totalBookedAppointment", totalAppointments);

                    Gson gson = new Gson();
                    out.print(gson.toJson(responseData));
                    out.flush();
                }
                break;
            case "getBookedAppointments":
                int getDoctorID = Integer.parseInt(request.getParameter("doctorID"));
                String appointmentDate = request.getParameter("appointmentDate");

                List<Appointment> bookedAppointments = Appointment.getBookedAppointmentsByDoctorAndDate(getDoctorID, appointmentDate);

                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                PrintWriter out = response.getWriter();

                Gson gson = new Gson();
                out.print(gson.toJson(bookedAppointments));
                out.flush();
                break;
            case "Print":
                int appointmentID = Integer.parseInt(request.getParameter("id"));

                Appointment bookedAppointment = Appointment.getBookedAppointmentById(appointmentID);
                request.setAttribute("bookedAppointment", bookedAppointment);
                request.getRequestDispatcher("Application/patientAppointment/Invoice.jsp").forward(request, response);
                break;
            default:
                // Load list of doctors for the form
                List<Doctor> doctors = patientAppointmentService.getAllDoctors();
                request.setAttribute("doctors", doctors);

                // Load list of treatments for the form
                List<Treatment> treatments = patientAppointmentService.getAllTreatments();
                request.setAttribute("treatments", treatments);

                request.getRequestDispatcher("Application/patientAppointment/PatientAppointment.jsp").forward(request, response);
                break;
        }
    }

    // Method to search for an existing patient by NIC
    private void searchPatient(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String NIC = request.getParameter("NIC");
        Patient patient = patientAppointmentService.searchPatientByNIC(NIC);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if (patient != null) {
            String jsonResponse = String.format("{\"exists\": true, \"patientID\": %d, \"name\": \"%s\", \"email\": \"%s\", \"telephone\": \"%s\"}",
                    patient.getPatientID(), patient.getName(), patient.getEmail(), patient.getTelephone());
            response.getWriter().write(jsonResponse);
        } else {
            response.getWriter().write("{\"exists\": false}");
        }
    }

    // Method to register a patient and book an appointment
    private void registerPatientAndBookAppointment(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Patient Details
        String NIC = request.getParameter("NIC");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String telephone = request.getParameter("telephone");

        // Appointment Details
        int doctorID = Integer.parseInt(request.getParameter("doctorID"));
        int treatmentID = Integer.parseInt(request.getParameter("treatmentID"));
        String appointmentDate = request.getParameter("appointmentDate");

        // Check if patient already exists by NIC
        Patient patient = patientAppointmentService.searchPatientByNIC(NIC);
        if (patient == null) {
            // If not exists, create new Patient and save to the database
            patient = patientAppointmentService.registerNewPatient(NIC, name, email, telephone);
        }

        // Create new Appointment and save to the database
        patientAppointmentService.bookAppointment(patient, doctorID, treatmentID, appointmentDate);

        // Redirect to a confirmation page
        response.sendRedirect("success.jsp");
    }

}
