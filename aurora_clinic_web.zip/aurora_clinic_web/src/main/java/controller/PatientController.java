package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Patient;
import service.PatientService;

import java.io.IOException;
import java.util.List;

@WebServlet("/PatientController")
public class PatientController extends HttpServlet {

    private PatientService patientService;

    @Override
    public void init() throws ServletException {
        patientService = new PatientService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        switch (action) {
            case "list":
                listPatients(request, response);
                break;
            case "view":
                viewPatient(request, response);
                break;
            case "edit":
                editPatient(request, response);
                break;
            case "add":
                showAddPatientForm(request, response);
                break;
            default:
                response.sendRedirect("index.jsp");
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        switch (action) {
            case "update":
                updatePatient(request, response);
                break;
            case "add":
                addNewPatient(request, response);
                break;
        }
    }

    // Method to list all patients
    private void listPatients(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Patient> patients = patientService.getAllPatients();
        request.setAttribute("patients", patients);
        request.getRequestDispatcher("Application/patient/listPatients.jsp").forward(request, response);
    }

    // Method to view a specific patient's details
    private void viewPatient(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int patientID = Integer.parseInt(request.getParameter("id"));
        Patient patient = patientService.getPatientByID(patientID);
        request.setAttribute("patient", patient);
        request.getRequestDispatcher("Application/patient/viewPatient.jsp").forward(request, response);
    }

    // Method to show the edit form for a specific patient
    private void editPatient(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int patientID = Integer.parseInt(request.getParameter("id"));
        Patient patient = patientService.getPatientByID(patientID);
        request.setAttribute("patient", patient);
        request.getRequestDispatcher("Application/patient/editPatient.jsp").forward(request, response);
    }

    // Method to handle updating a patient's information
    private void updatePatient(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int patientID = Integer.parseInt(request.getParameter("patientID"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String telephone = request.getParameter("telephone");
        String nic = request.getParameter("nic");

        boolean isUpdated = patientService.updatePatient(patientID, nic, name, email, telephone);

        if (isUpdated) {
            response.sendRedirect("PatientController?action=list");
        } else {
            response.sendRedirect("error.jsp");
        }
    }

    // Method to show the add patient form
    private void showAddPatientForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("Application/patient/addPatient.jsp").forward(request, response);
    }

    // Method to add a new patient
    private void addNewPatient(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String telephone = request.getParameter("telephone");
        String nic = request.getParameter("nic");

        // Check if patient with this NIC already exists
        if (patientService.doesPatientExist(nic)) {
            // Redirect to an error page or show a message indicating the NIC is already registered
            request.getRequestDispatcher("Application/patient/addPatient.jsp?error=exists").forward(request, response);
            return;
        }

        // Add new patient if NIC does not already exist
        patientService.addPatient(nic, name, email, telephone);
        response.sendRedirect("PatientController?action=list");
    }
}
