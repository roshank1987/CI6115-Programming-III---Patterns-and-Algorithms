package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import service.DoctorService;
import model.Doctor;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/DoctorController")
public class DoctorController extends HttpServlet {

    private DoctorService doctorService;

    @Override
    public void init() throws ServletException {
        // Initialize the service
        doctorService = new DoctorService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle form submissions based on action parameter
        String action = request.getParameter("action");

        switch (action) {
            case "add":
                addDoctor(request, response);
                break;
            case "update":
                updateDoctor(request, response);
                break;
            case "delete":
                deleteDoctor(request, response);
                break;
            default:
                response.sendRedirect("error.jsp");
                break;
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle GET requests based on action parameter
        String action = request.getParameter("action");

        switch (action) {
            case "list":
                listDoctors(request, response);
                break;
            case "view":
                viewDoctor(request, response);
                break;
            case "edit":
                editDoctor(request, response);
                break;
            case "add":
                showAddDoctirForm(request, response);
                break;
            default:
                request.getRequestDispatcher("index.jsp").forward(request, response);
                break;
        }
    }

    // Method to show the add patient form
    private void showAddDoctirForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("Application/doctor/addDoctor.jsp").forward(request, response);
    }

    // Method to add a new doctor
    private void addDoctor(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String name = request.getParameter("name");
        String specialized = request.getParameter("specialized");
        String telephone = request.getParameter("telephone");

        // Create a map to hold the availability for each day
        Map<String, List<Doctor.TimeSlot>> availability = new HashMap<>();

        // Add time slots for each day (only one slot per day)
        addTimeSlot(request, "Monday", availability);
        addTimeSlot(request, "Tuesday", availability);
        addTimeSlot(request, "Wednesday", availability);
        addTimeSlot(request, "Thursday", availability);
        addTimeSlot(request, "Friday", availability);
        addTimeSlot(request, "Saturday", availability);
        addTimeSlot(request, "Sunday", availability);

        // Use service to add the doctor
        doctorService.addDoctor(name, specialized, telephone, availability);
        response.sendRedirect("success.jsp");
    }

    // Helper method to extract a single time slot from the request and add it to the availability map
    private void addTimeSlot(HttpServletRequest request, String day, Map<String, List<Doctor.TimeSlot>> availability) {
        String fromTime = request.getParameter(day + "From");
        String toTime = request.getParameter(day + "To");

        // Check if both times are provided
        if (fromTime != null && !fromTime.isEmpty() && toTime != null && !toTime.isEmpty()) {

            LocalTime startTime = LocalTime.parse(fromTime);
            LocalTime endTime = LocalTime.parse(toTime);

            Duration duration = Duration.between(startTime, endTime);
            long totalMinutes = duration.toMinutes();

            // Calculate the number of 15-minute intervals
            long intervals = totalMinutes / 15;
            
            
            // Create a list with a single time slot
            List<Doctor.TimeSlot> timeSlots = new ArrayList<>();
            timeSlots.add(new Doctor.TimeSlot(fromTime, toTime, intervals));

            // Add to the availability map
            availability.put(day, timeSlots);
        }
    }

    // Method to handle editing a doctor
    private void editDoctor(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the doctor's ID from the request
        int doctorID = Integer.parseInt(request.getParameter("id"));

        // Fetch the doctor details from the service
        Doctor doctor = doctorService.getDoctorByID(doctorID);

        // Set the doctor as an attribute to pass it to the JSP
        request.setAttribute("doctor", doctor);

        // Forward the request to editDoctor.jsp
        request.getRequestDispatcher("Application/doctor/editDoctor.jsp").forward(request, response);
    }

    // Method to update doctor information
    private void updateDoctor(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int doctorID = Integer.parseInt(request.getParameter("doctorID"));
        String name = request.getParameter("name");
        String specialized = request.getParameter("specialized");
        String telephone = request.getParameter("telephone");

        boolean isUpdated = doctorService.updateDoctor(doctorID, name, specialized, telephone);
        if (isUpdated) {
            response.sendRedirect("DoctorController?action=list");
        } else {
            response.sendRedirect("error.jsp");
        }
    }

    // Method to delete a doctor by ID
    private void deleteDoctor(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int doctorID = Integer.parseInt(request.getParameter("doctorID"));

        boolean isDeleted = doctorService.deleteDoctor(doctorID);
        if (isDeleted) {
            response.sendRedirect("DoctorController?action=list");
        } else {
            response.sendRedirect("error.jsp");
        }
    }

    // Method to list all doctors
    private void listDoctors(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Doctor> doctors = doctorService.getAllDoctors();
        request.setAttribute("doctors", doctors);
        request.getRequestDispatcher("Application/doctor/listDoctors.jsp").forward(request, response);
    }

    // Method to view a single doctor's details
    private void viewDoctor(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int doctorID = Integer.parseInt(request.getParameter("doctorID"));
        Doctor doctor = doctorService.getDoctorByID(doctorID);

        if (doctor != null) {
            request.setAttribute("doctor", doctor);
            request.getRequestDispatcher("Application/doctor/doctor-details.jsp").forward(request, response);
        } else {
            response.sendRedirect("error.jsp");
        }
    }
}
