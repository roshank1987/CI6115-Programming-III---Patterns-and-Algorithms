package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import service.TreatmentService;
import model.Treatment;

import java.io.IOException;
import java.util.List;

@WebServlet("/TreatmentController")
public class TreatmentController extends HttpServlet {

    private TreatmentService treatmentService;

    @Override
    public void init() throws ServletException {
        treatmentService = new TreatmentService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        switch (action) {
            case "add":
                addTreatment(request, response);
                break;
            case "update":
                updateTreatment(request, response);
                break;
            case "delete":
                deleteTreatment(request, response);
                break;
            default:
                response.sendRedirect("error.jsp");
                break;
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        switch (action) {
            case "list":
                listTreatments(request, response);
                break;
            case "view":
                viewTreatment(request, response);
                break;
            case "edit":
                editTreatment(request, response);
                break;
            case "add":
                showAddTreatmentForm(request, response);
                break;
            default:
                request.getRequestDispatcher("index.jsp").forward(request, response);
                break;
        }
    }

    private void showAddTreatmentForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("Application/treatment/addTreatment.jsp").forward(request, response);
    }

    private void addTreatment(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String name = request.getParameter("name");
        double price = Double.parseDouble(request.getParameter("price"));
        treatmentService.addTreatment(name, price);
        response.sendRedirect("success.jsp");
    }

    private void editTreatment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int treatmentID = Integer.parseInt(request.getParameter("id"));
        Treatment treatment = treatmentService.getTreatmentByID(treatmentID);
        request.setAttribute("treatment", treatment);
        request.getRequestDispatcher("Application/treatment/editTreatment.jsp").forward(request, response);
    }

    private void updateTreatment(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int treatmentID = Integer.parseInt(request.getParameter("treatmentID"));
        String name = request.getParameter("name");
        double price = Double.parseDouble(request.getParameter("price"));
        boolean isUpdated = treatmentService.updateTreatment(treatmentID, name, price);
        if (isUpdated) {
            response.sendRedirect("TreatmentController?action=list");
        } else {
            response.sendRedirect("error.jsp");
        }
    }

    private void deleteTreatment(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int treatmentID = Integer.parseInt(request.getParameter("treatmentID"));
        boolean isDeleted = treatmentService.deleteTreatment(treatmentID);
        if (isDeleted) {
            response.sendRedirect("TreatmentController?action=list");
        } else {
            response.sendRedirect("error.jsp");
        }
    }

    private void listTreatments(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Treatment> treatments = treatmentService.getAllTreatments();
        request.setAttribute("treatments", treatments);
        request.getRequestDispatcher("Application/treatment/listTreatments.jsp").forward(request, response);
    }

    private void viewTreatment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int treatmentID = Integer.parseInt(request.getParameter("treatmentID"));
        Treatment treatment = treatmentService.getTreatmentByID(treatmentID);
        if (treatment != null) {
            request.setAttribute("treatment", treatment);
            request.getRequestDispatcher("Application/treatment/treatment-details.jsp").forward(request, response);
        } else {
            response.sendRedirect("error.jsp");
        }
    }
}
