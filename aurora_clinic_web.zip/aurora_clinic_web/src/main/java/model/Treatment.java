package model;

import util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Treatment {

    private int treatmentID;
    private String treatmentName;
    private double price;

    public Treatment(int treatmentID, String treatmentName, double price) {
        this.treatmentID = treatmentID;
        this.treatmentName = treatmentName;
        this.price = price;
    }

    public Treatment(String treatmentName, double price) {
        this.treatmentName = treatmentName;
        this.price = price;
    }

    // Getters and Setters
    public int getTreatmentID() {
        return treatmentID;
    }

    public void setTreatmentID(int treatmentID) {
        this.treatmentID = treatmentID;
    }

    public String getTreatmentName() {
        return treatmentName;
    }

    public void setTreatmentName(String treatmentName) {
        this.treatmentName = treatmentName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // Method to save the treatment to the database
    public void saveToDatabase() {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "INSERT INTO Treatment (treatmentName, price) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, treatmentName);
            stmt.setDouble(2, price);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to retrieve a treatment by ID
    public static Treatment getTreatmentByID(int id) {
        Treatment treatment = null;
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM Treatment WHERE treatmentID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                treatment = new Treatment(
                        rs.getInt("treatmentID"),
                        rs.getString("treatmentName"),
                        rs.getDouble("price")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return treatment;
    }
}
