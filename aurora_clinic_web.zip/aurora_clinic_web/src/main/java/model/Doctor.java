package model;

import util.DatabaseUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Doctor extends Person {

    private int doctorID;
    private String specialized;
    private Map<String, List<TimeSlot>> availability;

    // Constructor for adding a new doctor (no ID)
    public Doctor(String name, String specialized, String telephone) {
        super(name, telephone);
        this.specialized = specialized;
        this.availability = new HashMap<>();
    }

    // Constructor for retrieving existing doctors from the database
    public Doctor(int doctorID, String name, String specialized, String telephone) {
        super(name, telephone);
        this.doctorID = doctorID;
        this.specialized = specialized;
        this.availability = new HashMap<>();
    }

    // Inner class to represent a time slot with "from" and "to" times
    public static class TimeSlot {

        private int availabilityID;
        private String day;
        private String fromTime;
        private String toTime;
        private long available;

        public TimeSlot(String fromTime, String toTime,long available) {
            this.fromTime = fromTime;
            this.toTime = toTime;
            this.available = available;
        }

        public TimeSlot(int availabilityID, String day, String fromTime, String toTime, long available) {
            this.availabilityID = availabilityID;
            this.day = day;
            this.fromTime = fromTime;
            this.toTime = toTime;
            this.available = available;
        }

        public int getAvailabilityID() {
            return availabilityID;
        }

        public String getDay() {
            return day;
        }

        public String getFromTime() {
            return fromTime;
        }

        public String getToTime() {
            return toTime;
        }

        public long getAvailable() {
            return available;
        }
    }

    // Getter and Setter methods
    public int getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(int doctorID) {
        this.doctorID = doctorID;
    }

    public String getSpecialized() {
        return specialized;
    }

    public void setSpecialized(String specialized) {
        this.specialized = specialized;
    }

    public Map<String, List<TimeSlot>> getAvailability() {
        return availability;
    }

    public void setAvailability(Map<String, List<TimeSlot>> availability) {
        this.availability = availability;
    }

    // Method to add availability with "from" and "to" times
    public void addAvailability(String day, String fromTime, String toTime, long available) {
        TimeSlot timeSlot = new TimeSlot(fromTime, toTime,available);
        availability.computeIfAbsent(day, k -> new ArrayList<>()).add(timeSlot);
    }

    // Save Doctor to Database, including availability
    public void saveToDatabase() {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "INSERT INTO doctors (name, specialized, telephone) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            stmt.setString(1, getName());
            stmt.setString(2, getSpecialized());
            stmt.setString(3, getTelephone());
            stmt.executeUpdate();

            // Get generated doctor ID
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                this.doctorID = rs.getInt(1);
            }

            // Save availability
            for (Map.Entry<String, List<TimeSlot>> entry : availability.entrySet()) {
                String day = entry.getKey();
                List<TimeSlot> timeSlots = entry.getValue();

                for (TimeSlot timeSlot : timeSlots) {
                    String availabilityQuery = "INSERT INTO doctor_availability (doctorID, day, fromTime, toTime,available) VALUES (?, ?, ?, ?,?)";
                    PreparedStatement availabilityStmt = conn.prepareStatement(availabilityQuery);
                    availabilityStmt.setInt(1, doctorID);
                    availabilityStmt.setString(2, day);
                    availabilityStmt.setString(3, timeSlot.getFromTime());
                    availabilityStmt.setString(4, timeSlot.getToTime());
                    availabilityStmt.setLong(5, timeSlot.getAvailable());
                    availabilityStmt.executeUpdate();
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Fetch Doctor and Availability by ID
    public static Doctor getDoctorByID(int id) {
        Doctor doctor = null;
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM doctors WHERE doctorID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                doctor = new Doctor(
                        rs.getInt("doctorID"),
                        rs.getString("name"),
                        rs.getString("specialized"),
                        rs.getString("telephone")
                );

                // Fetch availability
                String availabilityQuery = "SELECT * FROM doctor_availability WHERE doctorID = ?";
                PreparedStatement availabilityStmt = conn.prepareStatement(availabilityQuery);
                availabilityStmt.setInt(1, id);
                ResultSet availabilityRs = availabilityStmt.executeQuery();
                while (availabilityRs.next()) {
                    String day = availabilityRs.getString("day");
                    String fromTime = availabilityRs.getString("fromTime");
                    String toTime = availabilityRs.getString("toTime");
                    int available = Integer.parseInt(availabilityRs.getString("available"));
                    doctor.addAvailability(day, fromTime, toTime, available);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return doctor;
    }

    public List<TimeSlot> getAvailableTimeSlots(String appointmentDay) {
        List<TimeSlot> availableTimeSlots = new ArrayList<>();

        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT da.id, da.day, da.fromTime, da.toTime,da.available "
                    + "FROM doctor_availability da "
                    + "WHERE da.doctorID = ? AND da.day = ?";

            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, this.doctorID);
            stmt.setString(2, appointmentDay);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int availabilityID = rs.getInt("id");
                String day = rs.getString("day");
                String fromTime = rs.getString("fromTime");
                String toTime = rs.getString("toTime");
                int available = Integer.parseInt(rs.getString("available"));

                TimeSlot timeSlot = new TimeSlot(availabilityID, day, fromTime, toTime, available);
                availableTimeSlots.add(timeSlot);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return availableTimeSlots;
    }

}
