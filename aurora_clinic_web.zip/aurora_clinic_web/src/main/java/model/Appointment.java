package model;

import util.DatabaseUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Appointment {

    private int appointmentID; // Unique identifier for each appointment
    private Patient patient;   // Associated patient
    private Doctor doctor;     // Associated doctor
    private Treatment treatment;     // Associated doctor
    private String appointmentDate; // Appointment date (YYYY-MM-DD format)
    private int appointmentNo; // Appointment time (HH:MM format)
    private String status;     // Status of the appointment (e.g., Scheduled, Completed, Canceled)

    // Constructor for new appointments (without appointmentID)
    public Appointment(Patient patient, Doctor doctor, String appointmentDate, int appointmentNo, String status) {
        this.patient = patient;
        this.doctor = doctor;
        this.appointmentDate = appointmentDate;
        this.appointmentNo = appointmentNo;
        this.status = status;
    }

    // Constructor for existing appointments (with appointmentID)
    public Appointment(int appointmentID, Patient patient, Doctor doctor, Treatment treatment, String appointmentDate, int appointmentNo, String status) {
        this.appointmentID = appointmentID;
        this.patient = patient;
        this.doctor = doctor;
        this.treatment = treatment;
        this.appointmentDate = appointmentDate;
        this.appointmentNo = appointmentNo;
        this.status = status;
    }

    // Getters and Setters
    public int getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Treatment getTreatment() {
        return treatment;
    }

    public void setTreatment(Treatment treatment) {
        this.treatment = treatment;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public int getAppointmentNo() {
        return appointmentNo;
    }

    public void setAppointmentNo(int appointmentNo) {
        this.appointmentNo = appointmentNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Method to save the appointment to the database
    public void saveToDatabase() {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "INSERT INTO appointments (patientID, doctorID,treatmentID, appointmentDate, status,appointmentNo) "
                    + "SELECT ?, ?, ?, ?, ?, COALESCE(max_appointment + 1, 1) FROM (SELECT MAX(appointmentNo) AS max_appointment  FROM appointments WHERE doctorID = ? AND appointmentDate=?) AS temp";

            PreparedStatement stmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, patient.getPatientID());
            stmt.setInt(2, doctor.getDoctorID());
            stmt.setInt(3, treatment.getTreatmentID());
            stmt.setString(4, appointmentDate);
            stmt.setString(5, status);
            stmt.setInt(6, doctor.getDoctorID());
            stmt.setString(7, appointmentDate);

            int rowsAffected = stmt.executeUpdate();

            // If insertion was successful, get the generated ID
            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    this.appointmentID = rs.getInt(1); // Automatically assign the generated ID to the appointmentID field
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Static method to get an appointment by ID from the database
    public static Appointment getAppointmentByID(int appointmentID) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM appointments WHERE appointmentID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, appointmentID);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Patient patient = Patient.getPatientByID(rs.getInt("patientID"));
                Doctor doctor = Doctor.getDoctorByID(rs.getInt("doctorID"));
                Treatment treatment = Treatment.getTreatmentByID(rs.getInt("treatmentID"));
                return new Appointment(
                        rs.getInt("appointmentID"),
                        patient,
                        doctor,
                        treatment,
                        rs.getString("appointmentDate"),
                        rs.getInt("appointmentNo"),
                        rs.getString("status")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method to update the appointment details in the database
    public boolean updateInDatabase() {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "UPDATE appointments SET patientID = ?, doctorID = ?,treatmentID = ?, appointmentDate = ?, status = ? WHERE appointmentID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, patient.getPatientID());
            stmt.setInt(2, doctor.getDoctorID());
            stmt.setInt(3, treatment.getTreatmentID());
            stmt.setString(4, appointmentDate);
            stmt.setString(5, status);
            stmt.setInt(6, appointmentID);

            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to delete the appointment from the database
    public boolean deleteFromDatabase() {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "DELETE FROM appointments WHERE appointmentID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, appointmentID);

            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to get total appoinment count
    public static int getAppointmentCountByDoctorAndDate(int doctorID, String appointmentDate) {
        int count = 0;
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT COUNT(*) AS appointment_count FROM appointments WHERE doctorID = ? AND appointmentDate = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, doctorID);
            stmt.setString(2, appointmentDate);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                count = rs.getInt("appointment_count");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    public static List<Appointment> getBookedAppointmentsByDoctorAndDate(int doctorID, String appointmentDate) {
        List<Appointment> appointments = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM appointments WHERE doctorID = ? AND appointmentDate = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, doctorID);
            stmt.setString(2, appointmentDate);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Patient patient = Patient.getPatientByID(rs.getInt("patientID"));
                Doctor doctor = Doctor.getDoctorByID(rs.getInt("doctorID"));
                Treatment treatment = Treatment.getTreatmentByID(rs.getInt("treatmentID"));
                Appointment appointment = new Appointment(
                        rs.getInt("appointmentID"),
                        patient,
                        doctor,
                        treatment,
                        rs.getString("appointmentDate"),
                        rs.getInt("appointmentNo"),
                        rs.getString("status")
                );
                appointments.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return appointments;
    }

    public static Appointment getBookedAppointmentById(int appointmentID) {
        Appointment appointment = null;
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM appointments WHERE appointmentID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, appointmentID);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Patient patient = Patient.getPatientByID(rs.getInt("patientID"));
                Doctor doctor = Doctor.getDoctorByID(rs.getInt("doctorID"));
                Treatment treatment = Treatment.getTreatmentByID(rs.getInt("treatmentID"));
                appointment = new Appointment(
                        rs.getInt("appointmentID"),
                        patient,
                        doctor,
                        treatment,
                        rs.getString("appointmentDate"),
                        rs.getInt("appointmentNo"),
                        rs.getString("status")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return appointment;
    }
}
