package model;

import util.DatabaseUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Patient extends Person {

    private int patientID; // Unique identifier for each patient
    private String NIC;    // National ID Card or unique identifier

    // Constructor for adding a new patient (no ID)
    public Patient(String NIC, String name, String email, String telephone) {
        super(name, email, telephone);
        this.NIC = NIC;
    }

    // Constructor for retrieving existing patients from the database
    public Patient(int patientID, String NIC, String name, String email, String telephone) {
        super(name, email, telephone);
        this.patientID = patientID;
        this.NIC = NIC;
    }

    // Getters and Setters
    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public String getNIC() {
        return NIC;
    }

    public void setNIC(String NIC) {
        this.NIC = NIC;
    }

    // Method to save the patient to the database
    public void saveToDatabase() {
        try (Connection conn = DatabaseUtil.getConnection()) {
            // Prepare the SQL insert query
            String query = "INSERT INTO patients (NIC, name, email, telephone) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            stmt.setString(1, getNIC());
            stmt.setString(2, getName());
            stmt.setString(3, getEmail());
            stmt.setString(4, getTelephone());

            // Execute the update
            int rowsAffected = stmt.executeUpdate();

            // If insertion was successful, get the generated ID
            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    this.patientID = rs.getInt(1); // Automatically assign the generated ID to the patientID field
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Log the SQL exception
        }
    }

    // Static method to get a patient by ID from the database
    public static Patient getPatientByID(int patientID) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM patients WHERE patientID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, patientID);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Patient(
                    rs.getInt("patientID"),
                    rs.getString("NIC"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("telephone")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Static method to get a patient by NIC from the database
    public static Patient getPatientByNIC(String NIC) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM patients WHERE NIC = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, NIC);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Patient(
                    rs.getInt("patientID"),
                    rs.getString("NIC"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("telephone")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method to update the patient's details in the database
    public boolean updateInDatabase() {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "UPDATE patients SET NIC = ?, name = ?, email = ?, telephone = ? WHERE patientID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, getNIC());
            stmt.setString(2, getName());
            stmt.setString(3, getEmail());
            stmt.setString(4, getTelephone());
            stmt.setInt(5, getPatientID());
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to delete the patient from the database
    public boolean deleteFromDatabase() {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "DELETE FROM patients WHERE patientID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, getPatientID());
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
